import argparse, os, time
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from dataset import SequenceDataset
from model import MultiCNNPolicy
from tqdm import tqdm

def train(args):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    ds = SequenceDataset(args.data)
    num_actions = int(ds.labels.max()) + 1
    model = MultiCNNPolicy(num_actions=num_actions,
                           in_channels_state=ds.states.shape[1],
                           in_channels_buttons=ds.buttons.shape[1]).to(device)

    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=True, num_workers=0)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
    criterion = nn.CrossEntropyLoss()

    model.train()
    for epoch in range(1, args.epochs+1):
        pbar = tqdm(loader, desc=f"Epoch {epoch}/{args.epochs}")
        total, correct, loss_sum = 0, 0, 0.0
        for (s, b), y in pbar:
            s = s.to(device)
            b = b.to(device)
            y = y.to(device)

            opt.zero_grad()
            logits = model(s, b)
            loss = criterion(logits, y)
            loss.backward()
            opt.step()

            with torch.no_grad():
                pred = logits.argmax(dim=1)
                total += y.size(0)
                correct += (pred == y).sum().item()
                loss_sum += loss.item() * y.size(0)
                pbar.set_postfix(loss=loss_sum/total, acc=correct/total)

    # Save
    stamp = time.strftime("%Y%m%d_%H%M%S")
    out_dir = os.path.join(os.path.dirname(__file__), "..", "outputs", stamp)
    latest_link = os.path.join(os.path.dirname(__file__), "..", "outputs", "latest")
    os.makedirs(out_dir, exist_ok=True)
    torch.save(model.state_dict(), os.path.join(out_dir, "model.pt"))
    # Update 'latest' symlink/dir copy
    if os.path.islink(latest_link) or os.path.exists(latest_link):
        try:
            if os.path.islink(latest_link):
                os.unlink(latest_link)
            else:
                import shutil; shutil.rmtree(latest_link)
        except Exception:
            pass
    try:
        os.symlink(out_dir, latest_link)
    except Exception:
        # On Windows or restricted FS, just ensure a copy exists
        import shutil
        shutil.copytree(out_dir, latest_link, dirs_exist_ok=True)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True, help=".npz file with states/buttons/labels")
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--lr", type=float, default=1e-3)
    args = parser.parse_args()
    train(args)