import torch
import torch.nn as nn
import torch.nn.functional as F

def _make_cnn_block(in_ch, out_ch):
    return nn.Sequential(
        nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1),
        nn.ReLU(inplace=True),
        nn.MaxPool2d(kernel_size=2)
    )

class MultiCNNPolicy(nn.Module):
    def __init__(self, num_actions:int, in_channels_state:int=3, in_channels_buttons:int=1):
        super().__init__()
        # Branch A: states
        self.state_cnn = nn.Sequential(
            _make_cnn_block(in_channels_state, 16),
            _make_cnn_block(16, 32),
            nn.Flatten()
        )
        # Branch B: buttons
        self.button_cnn = nn.Sequential(
            _make_cnn_block(in_channels_buttons, 8),
            _make_cnn_block(8, 16),
            nn.Flatten()
        )
        # We'll infer flattened dims at runtime; use lazy layers
        self.fc = nn.Sequential(
            nn.LazyLinear(256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.2),
            nn.Linear(256, num_actions)
        )

    def forward(self, state_img, button_img):
        fs = self.state_cnn(state_img)   # (N, *)
        fb = self.button_cnn(button_img) # (N, *)
        x = torch.cat([fs, fb], dim=1)
        logits = self.fc(x)
        return logits