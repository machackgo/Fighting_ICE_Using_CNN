# Multi‑CNN Fighting Game Agent (Starter Kit)

You will build an **AI player** for a fighting game environment (e.g., FightingICE).
The agent reads short **sequences of game state + button inputs** (turned into image‑like tensors),
runs them through a **multi‑branch CNN**, and outputs the **next action** (policy).

> Scope: You are **not** building a new game. You are building a **controller/agent** that plugs into an existing engine.

## Repository layout
```
cnn_fighting_agent/
├── data/                       # Put your recorded matches (.npz) here
├── docs/
│   └── design.md               # Design notes (start here)
├── src/
│   ├── dataset.py              # Loads sequences -> tensors
│   ├── model.py                # Multi-branch CNN
│   ├── train.py                # Behavior cloning training loop
│   ├── eval.py                 # Offline evaluation
│   ├── generate_dummy_data.py  # Creates a toy dataset to test the pipeline
│   └── fightingice_runner.py   # Placeholder for live inference loop
├── outputs/                    # Trained weights, logs
├── requirements.txt
└── README.md
```

## Quick start (offline, with dummy data)
1. (Recommended) Use Python **3.10 or 3.11**. Newer (3.13) builds of PyTorch may not be available yet.
   ```bash
   python -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt
   ```
2. Create a small synthetic dataset and train an end‑to‑end sanity check:
   ```bash
   python src/generate_dummy_data.py --out data/samples.npz
   python src/train.py --data data/samples.npz --epochs 5 --batch_size 64
   python src/eval.py --data data/samples.npz --weights outputs/latest/model.pt
   ```

## Real data shape (behavior cloning)
We expect an `.npz` file with numpy arrays:
- `states`:  (N, C_state, T, F_state)    e.g., channels for [hp, x, y, vx, vy, distance]
- `buttons`: (N, C_buttons, T, B)        e.g., one‑hot button history
- `labels`:  (N,)                         integer action id (0..K‑1)

The network predicts the **next action** after each T‑length window.

## Going live (later)
- Implement `src/fightingice_runner.py` to read the environment's observation and maintain sliding windows.
- Call the trained PyTorch model to get an action each step and send it to the engine.

## Deliverables to your team
- Data pipeline + loader
- Multi‑CNN model and training scripts
- Trained weights + offline metrics
- Short demo video/GIF of agent acting in the environment
- 1‑2 page write‑up summarizing your design and results